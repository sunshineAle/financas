// Servidor local mínimo (sem dependências) para testar o app instalável.
// Uso: node servir.cjs  →  abra http://localhost:5173 no Chrome/Edge e use "Instalar app".
const http = require('http'), fs = require('fs'), path = require('path');
const raiz = __dirname, porta = Number(process.env.PORT) || 5173;
const tipos = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.wasm': 'application/wasm' };
http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]); if (p.endsWith('/')) p += 'index.html';
  const f = path.join(raiz, path.normalize(p));
  if (!f.startsWith(raiz)) { res.writeHead(403); return res.end(); }
  fs.readFile(f, (e, d) => {
    if (e) { res.writeHead(404); return res.end('Não encontrado'); }
    res.writeHead(200, { 'Content-Type': tipos[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(d);
  });
}).listen(porta, () => console.log('Sistema Financeiro (PWA) em http://localhost:' + porta + '  — Ctrl+C para parar'));
